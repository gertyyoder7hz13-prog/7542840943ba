// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Simulate kingfisher dive\n", stdout);
  return lionss_run_workload("kingfisher-3");
}
