// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Inject latency fault\n", stdout);
  return lionss_run_workload("chaoslatency");
}
